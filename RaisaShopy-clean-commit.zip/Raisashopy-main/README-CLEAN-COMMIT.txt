RAISA SHOPY - CLEAN COMMIT

This package contains the current website files and product photos.

To replace old GitHub commit history:
1. Download/clone the Raisashopy repository from GitHub.
2. Put these website files into the cloned repository (or use this folder as the working tree).
3. Open Command Prompt in the repository folder.
4. Run: replace-history.bat

The script creates an orphan main branch, commits all current files as one new commit, and force-pushes it to origin/main.

IMPORTANT: This removes old main-branch history from the remote branch. It does not delete the GitHub repository itself.
Back up anything important before running it.
