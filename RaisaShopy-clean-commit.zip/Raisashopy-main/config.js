const STORE={
 whatsapp:"966500000000", // replace with your WhatsApp number, country code first
 name:"Your Product Name",
 oldPrice:150,
 newPrice:99,
 currency:"SAR",
 description:"Write your product description here.\n\nAdd size, color, features, delivery details, etc.",
 images:["images/product-1.jpg","images/product-2.jpg","images/product-3.jpg","images/product-4.jpg"]
};
