@echo off
setlocal
cd /d "%~dp0"
echo This will replace the GitHub main branch history with ONE new commit.
echo Make sure this folder is a clone of your Raisashopy repository.
pause

git checkout --orphan new-main
if errorlevel 1 goto :error
git add -A
if errorlevel 1 goto :error
git commit -m "Raisa Shopy new website with photos"
if errorlevel 1 goto :error
git branch -D main
if errorlevel 1 goto :error
git branch -m main
git push -f origin main
if errorlevel 1 goto :error

echo.
echo DONE. The remote main branch now has the new single commit.
pause
exit /b 0
:error
echo.
echo Something went wrong. The repository was not fully replaced.
pause
exit /b 1
